let isHighlighted = false; 
function toggleHighlight(searchString) {
    if (!searchString) {
        console.warn("Search string is empty");
        return;
    }

    const elements = document.querySelectorAll("*"); 
    elements.forEach((element) => {
        if (element.children.length === 0) { 
            if (isHighlighted) {
                element.innerHTML = element.innerHTML.replace(/<span style="background-color: yellow;">(.*?)<\/span>/gi, "$1");
            } else {
                const regex = new RegExp(`(${searchString})`, "gi"); 
                element.innerHTML = element.innerHTML.replace(regex, `<span style="background-color: yellow;">$1</span>`);
            }
        }
    });

    isHighlighted = !isHighlighted; 
    console.log(`Toggled highlight for "${searchString}". Current state: ${isHighlighted ? 'Highlighted' : 'Unhighlighted'}`);
}
