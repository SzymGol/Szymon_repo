document.getElementById('registrationForm').addEventListener('submit', function (event) {
    event.preventDefault();

    resetErrors();

    let isValid = true;
    const formData = {};

    const userId = document.getElementById('userId').value;
    if (userId.length < 5 || userId.length > 12) {
        setError('userId', "Required and must be of length 5 to 12.");
        isValid = false;
    } else {
        formData.userId = userId;
    }

    const password = document.getElementById('password').value;
    if (password.length < 7 || password.length > 12) {
        setError('password', "Required and must be of length 7 to 12.");
        isValid = false;
    } else {
        formData.password = password;
    }

    const name = document.getElementById('name').value;
    if (!/^[A-Za-z]+$/.test(name)) {
        setError('name', "Required and alphabets only.");
        isValid = false;
    } else {
        formData.name = name;
    }

    const country = document.getElementById('country').value;
    if (country === "") {
        setError('country', "Required. Must select a country.");
        isValid = false;
    } else {
        formData.country = country;
    }

    const zipCode = document.getElementById('zipCode').value;
    if (!/^\d+$/.test(zipCode)) {
        setError('zipCode', "Required. Must be numeric only.");
        isValid = false;
    } else {
        formData.zipCode = zipCode;
    }

    const email = document.getElementById('email').value;
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!emailPattern.test(email)) {
        setError('email', "Required. Must be a valid email.");
        isValid = false;
    } else {
        formData.email = email;
    }

    const sex = document.querySelector('input[name="sex"]:checked');
    if (!sex) {
        setError('sex', "Required.");
        isValid = false;
    } else {
        formData.sex = sex.value;
    }

    const language = document.querySelector('input[name="language"]:checked');
    if (!language) {
        setError('language', "Required.");
        isValid = false;
    } else {
        formData.language = language.value;
    }

    const about = document.getElementById('about').value;
    if (about) {
        formData.about = about;
    }

    if (isValid) {
        console.log("Form Data (JSON):", JSON.stringify(formData));
        alert("Form submitted successfully! Check the console for JSON output.");
    }
});

function resetErrors() {
    const errorElements = document.querySelectorAll('.required');
    errorElements.forEach(element => element.textContent = "");

    const inputElements = document.querySelectorAll('input, select, textarea');
    inputElements.forEach(input => input.classList.remove('error'));
}

function setError(id, message) {
    document.getElementById(id + 'Error').textContent = message;
    document.getElementById(id).classList.add('error');
}
