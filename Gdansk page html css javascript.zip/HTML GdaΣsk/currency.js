function convertCurrency() {
  const amount = document.getElementById("amount").value;
  const fromCurrency = document.getElementById("fromCurrency").value;
  const toCurrency = document.getElementById("toCurrency").value;

  if (!amount || isNaN(amount) || amount <= 0) {
      alert("Please enter a valid amount.");
      return;
  }
  if (!fromCurrency || !toCurrency) {
      alert("Please select both source and destination currencies.");
      return;
  }

  const apiUrl = `https://api.exchangerate-api.com/v4/latest/${fromCurrency}`;

  fetch(apiUrl)
      .then(response => response.json())
      .then(data => {
          if (data && data.rates && data.rates[toCurrency]) {
              const rate = data.rates[toCurrency];
              const result = (amount * rate).toFixed(2);
              document.getElementById("result").innerText = `Converted: ${result} ${toCurrency}`;
          } else {
              alert("Error fetching exchange rates.");
          }
      })
      .catch(error => {
          console.error("Error connecting to API:", error);
          alert("Connection error.");
      });
}
