const apiKey = '3b2261be119b43edac8a3594768a6c9c';
const city = 'Gdansk';
const apiUrl = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=en`;

function getWeather() {
    fetch(apiUrl)
        .then(response => response.json())
        .then(data => {
            if (data.cod === 200) {
                const temp = data.main.temp;
                const description = data.weather[0].description;
                const icon = data.weather[0].icon;
                const humidity = data.main.humidity;
                const windSpeed = data.wind.speed;

                const weatherInfo = `
                    <h2>Current Temperature: ${temp}°C</h2>
                    <p>Description: ${description}</p>
                    <p>Humidity: ${humidity}%</p>
                    <p>Wind Speed: ${windSpeed} m/s</p>
                    <img src="https://openweathermap.org/img/wn/${icon}.png" alt="Weather" />
                `;
                document.getElementById('weather-info').innerHTML = weatherInfo;
            } else {
                document.getElementById('weather-info').innerHTML = 'Failed to fetch weather data.';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('weather-info').innerHTML = 'An error occurred while loading data.';
        });
}

window.onload = getWeather;
