document.addEventListener('DOMContentLoaded', function () {
    var map = L.map('map').setView([54.352, 18.646], 13);

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap contributors'
    }).addTo(map);

    var gdańskIcon = L.icon({
        iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
        iconSize: [25, 41],
        iconAnchor: [12, 41],
        popupAnchor: [1, -34],
        shadowSize: [41, 41]
    });

    var gdańskMarker = L.marker([54.352, 18.646], { icon: gdańskIcon }).addTo(map);
    gdańskMarker.bindPopup("<b>Gdańsk</b><br>Poland's beautiful port city.").openPopup();

    var hotspots = [
        {
            title: "St. Mary's Church",
            summary: "One of the largest brick churches in the world, located in Gdańsk's Old Town.",
            lat: 54.349808,
            lng: 18.652998,
            wikipediaUrl: "https://en.wikipedia.org/wiki/St._Mary%27s_Church,_Gda%C5%84sk"
        },
        {
            title: "Neptune's Fountain",
            summary: "A symbol of Gdańsk, located in the historic Long Street.",
            lat: 54.348546,
            lng: 18.653228,
            wikipediaUrl: "https://en.wikipedia.org/wiki/Neptune%27s_Fountain,_Gda%C5%84sk"
        },
        {
            title: "Gdańsk Crane",
            summary: "A medieval port crane and one of the city's defining landmarks.",
            lat: 54.350541,
            lng: 18.657491,
            wikipediaUrl: "https://www.galar.org/en/gdansk-crane/"
        },
        {
            title: "European Solidarity Centre",
            summary: "A museum and library dedicated to the history of Solidarity and the opposition to communism in Poland.",
            lat: 54.361355,
            lng: 18.649430,
            wikipediaUrl: "https://en.wikipedia.org/wiki/European_Solidarity_Centre"
        },
        {
            title: "Westerplatte",
            summary: "A historic site where World War II began, featuring a museum and memorial.",
            lat: 54.409395,
            lng: 18.669739,
            wikipediaUrl: "https://en.wikipedia.org/wiki/Westerplatte"
        },
        {
            title: "Museum of the Second World War",
            summary: "A museum dedicated to World War II history.",
            lat: 54.355941,
            lng: 18.661121,
            wikipediaUrl: "https://en.wikipedia.org/wiki/Museum_of_the_Second_World_War"
        },
        {
            title: "Oliwa Park",
            summary: "A historic park in Gdańsk.",
            lat: 54.411112,
            lng: 18.562534,
            wikipediaUrl: "https://pl.wikipedia.org/wiki/Park_Oliwski"
        },
        {
            title: "Electricians Street",
            summary: "A party place in Gdańsk.",
            lat: 54.364504,
            lng: 18.648228
        },
        {
            title: "Food Hall in Gdańsk",
            summary: "A modern food hall in the city.",
            lat: 54.359618,
            lng: 18.654181
        },
        {
            title: "Gdańsk Stadium",
            summary: "A stadium in Gdańsk, used for football matches and events.",
            lat: 54.389919,
            lng: 18.640400,
            wikipediaUrl: "https://en.wikipedia.org/wiki/Gda%C5%84sk_Stadium"
        }
    ];

    hotspots.forEach(place => {
        var placeMarker = L.marker([place.lat, place.lng]).addTo(map);
        placeMarker.bindPopup(
            `<b>${place.title}</b><br>
            ${place.summary}<br>
            ${place.wikipediaUrl ? `<a href="${place.wikipediaUrl}" target="_blank">Read more</a>` : ''}`
        );
    });
});
