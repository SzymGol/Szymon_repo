document.getElementById('reviewForm').addEventListener('submit', function(event) {
    event.preventDefault(); 

    const review = {
        name: document.getElementById('reviewName').value,
        date_time: document.getElementById('reviewDateTime').value,
        message: document.getElementById('reviewMessage').value
    };

    fetch('/reviews', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(review)
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Error submitting review');
        }
        return response.json();
    })
    .then(data => {
        alert(data.message); 
        fetchReviews();      
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error submitting review. Please try again later.');
    });

    this.reset();
});
